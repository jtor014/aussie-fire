import AustralianFireCalculator from './AustralianFireCalculator.jsx'

function App() {
  return <AustralianFireCalculator />
}

export default App
